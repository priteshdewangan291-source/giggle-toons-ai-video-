require("dotenv").config();
const express = require("express");
const OpenAI = require("openai");

const app = express();
app.use(express.json({ limit: "1mb" }));

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Giggle Toons AI Video Studio</title>
<style>
*{box-sizing:border-box}body{margin:0;font-family:Arial,sans-serif;background:#0b1020;color:#fff}
.wrap{max-width:850px;margin:auto;padding:24px}.logo{font-size:28px;font-weight:800;margin-bottom:8px}
.sub{color:#aeb8d0;margin-bottom:24px}.card{background:#141b30;border:1px solid #293452;border-radius:18px;padding:20px;margin-bottom:18px}
label{display:block;margin:14px 0 7px;font-weight:700}textarea,select{width:100%;padding:14px;border-radius:12px;border:1px solid #394564;background:#0e1528;color:#fff;font-size:16px}
button{width:100%;padding:15px;border:0;border-radius:12px;background:#6c63ff;color:white;font-size:17px;font-weight:800;margin-top:18px}
button:disabled{opacity:.5}.status{margin-top:15px;color:#b9c3dc;white-space:pre-wrap}video{width:100%;border-radius:14px;margin-top:15px;display:none}
a{display:none;color:#fff;margin-top:14px;text-decoration:none;font-weight:700}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}@media(max-width:600px){.grid{grid-template-columns:1fr}}
</style></head>
<body><div class="wrap">
<div class="logo">🎬 Giggle Toons AI Video Studio</div>
<div class="sub">Text se AI cartoon video generate karein.</div>
<div class="card">
<label>Video Prompt</label>
<textarea id="prompt" rows="7" placeholder="Example: A cute little panda and rabbit play in a colorful school playground..."></textarea>
<div class="grid">
<div><label>Style</label><select id="style"><option>3D Cartoon</option><option>Realistic</option><option>Anime</option><option>Cinematic</option></select></div>
<div><label>Duration</label><select id="seconds"><option value="4">4 seconds</option><option value="8">8 seconds</option><option value="12">12 seconds</option></select></div>
</div>
<label>Aspect Ratio</label><select id="ratio"><option value="16:9">16:9 Landscape</option><option value="9:16">9:16 Shorts</option><option value="1:1">1:1 Square</option></select>
<button id="go">🎥 Generate Video</button>
<div class="status" id="status"></div>
<video id="video" controls></video>
<a id="download" download="giggle-toons-video.mp4">⬇️ Download MP4</a>
</div></div>
<script>
const $=id=>document.getElementById(id);
$("go").onclick=async()=>{
 const prompt=$("prompt").value.trim(); if(!prompt){$("status").textContent="Pehle prompt likhiye.";return}
 $("go").disabled=true;$("status").textContent="Video job create ho raha hai...";
 try{
  const r=await fetch("/api/videos",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({prompt,style:$("style").value,seconds:Number($("seconds").value),ratio:$("ratio").value})});
  const j=await r.json(); if(!r.ok) throw new Error(j.error||"Request failed");
  const id=j.id; $("status").textContent="AI video generate kar raha hai...";
  let done=false;
  while(!done){
   await new Promise(x=>setTimeout(x,5000));
   const s=await fetch("/api/videos/"+id); const d=await s.json();
   if(d.status==="completed"){done=true;$("status").textContent="Video ready!";const url="/api/videos/"+id+"/content";$("video").src=url;$("video").style.display="block";$("download").href=url;$("download").style.display="block"}
   else if(d.status==="failed"){throw new Error("Video generation failed")}
   else $("status").textContent="AI video generate ho raha hai... ("+(d.status||"processing")+")";
  }
 }catch(e){$("status").textContent="Error: "+e.message}finally{$("go").disabled=false}
};
</script></body></html>`;

app.get("/", (req,res)=>res.type("html").send(html));

app.post("/api/videos", async (req,res)=>{
 try{
  const {prompt,style="3D Cartoon",seconds=8,ratio="16:9"}=req.body||{};
  if(!prompt) return res.status(400).json({error:"Prompt is required"});
  if(![4,8,12].includes(Number(seconds))) return res.status(400).json({error:"Duration must be 4, 8, or 12 seconds"});
  const sizes={"16:9":"1280x720","9:16":"720x1280","1:1":"1024x1024"};
  const enhanced=`Create a ${style} video for children. Keep it colorful, cheerful, safe and family-friendly. ${prompt}`;
  const v=await client.videos.create({model:"sora-2",prompt:enhanced,seconds:Number(seconds),size:sizes[ratio]||sizes["16:9"]});
  res.json({id:v.id,status:v.status});
 }catch(e){console.error(e);res.status(500).json({error:e.message||"Video generation failed"});}
});

app.get("/api/videos/:id",async(req,res)=>{
 try{const v=await client.videos.retrieve(req.params.id);res.json(v)}
 catch(e){res.status(500).json({error:e.message})}
});

app.get("/api/videos/:id/content",async(req,res)=>{
 try{const content=await client.videos.downloadContent(req.params.id);res.setHeader("Content-Type","video/mp4");content.body.pipe(res)}
 catch(e){res.status(500).json({error:e.message})}
});

const port=process.env.PORT||3000;
app.listen(port,()=>console.log("Giggle Toons running on port "+port));
